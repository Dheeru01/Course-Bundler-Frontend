import React from 'react'

const Requests = () => {
  return (
    <div>Requests</div>
  )
}

export default Requests